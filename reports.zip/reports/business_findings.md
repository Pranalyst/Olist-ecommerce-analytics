# Business Findings

## Project Objective

This analysis evaluates marketplace performance across customers, products, and sellers using the Olist e-commerce dataset. The goal was to identify key revenue drivers, customer behavior patterns, and business growth opportunities.

---

# Executive Findings

### Revenue Concentration

Marketplace revenue is concentrated within a limited number of product categories and seller groups. The top three categories—Health & Beauty, Watches, and Bed/Bath/Table—contribute 26.17% of total revenue, while Top Revenue Sellers account for 29.21% of marketplace revenue.

**Business Impact:** Revenue dependence on a small subset of categories and sellers increases business risk and highlights the need for diversification.

### Customer Value Distribution

Customer spending is highly uneven. Although High Value Customers represent only 4.57% of customers, they contribute 25.53% of total revenue.

**Business Impact:** Retaining high-value customers can have a disproportionately positive impact on overall revenue.

### Customer Retention Challenge

The customer base consists of 90,557 one-time buyers and only 2,801 repeat buyers.

**Business Impact:** Customer retention represents one of the largest opportunities for long-term revenue growth.

---

# Customer Analytics Findings

### Customer Segmentation

* High Value Customers: 4.57%
* Medium Value Customers: 49.11%
* Low Value Customers: 46.32%

### Revenue Contribution

* High Value Customers: 25.53%
* Medium Value Customers: 57.54%
* Low Value Customers: 16.93%

**Insight:** A small proportion of customers generates a significant share of marketplace revenue, making customer retention and targeted marketing critical.

---

# Product & Revenue Analytics Findings

### Top Revenue Categories

1. Health & Beauty (9.39%)
2. Watches (8.98%)
3. Bed/Bath/Table (7.80%)

Together, these categories generate 26.17% of total revenue.

### Customer Satisfaction

Analysis of category revenue and review scores revealed that certain high-revenue categories have lower customer ratings than others.

**Insight:** Improving customer experience within high-revenue categories can protect future revenue growth and strengthen customer loyalty.

---

# Seller Analytics Findings

### Seller Revenue Distribution

* Top Revenue Sellers contribute 29.21% of marketplace revenue.
* Revenue generation is concentrated among a relatively small group of sellers.

### Seller Performance

Analysis of seller revenue and review scores identified variations in customer satisfaction across seller segments.

**Insight:** Monitoring high-revenue sellers with below-average review scores can help improve overall marketplace quality.

---

# Business Recommendations

### 1. Improve Customer Retention

Implement loyalty programs, personalized recommendations, and post-purchase engagement strategies to increase repeat purchases.

### 2. Focus on High-Value Customers

Develop targeted campaigns and retention initiatives for High Value Customers to maximize customer lifetime value.

### 3. Invest in High-Performing Categories

Allocate additional marketing and operational resources to categories that demonstrate strong revenue and customer satisfaction.

### 4. Strengthen Seller Performance Monitoring

Track seller review scores and performance metrics to identify quality issues before they impact customer experience.

---

# Conclusion

The analysis reveals that marketplace revenue is heavily concentrated among a small number of customers, categories, and sellers. The most impactful growth opportunities lie in improving customer retention, supporting high-performing categories, and maintaining seller quality standards.
