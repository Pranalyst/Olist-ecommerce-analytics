# Olist E-Commerce Dataset - Data Dictionary

## Overview

This project analyzes the Brazilian Olist marketplace dataset to understand:

- Revenue performance
- Customer behavior
- Product performance
- Seller performance
- Delivery efficiency

---

## Tables

### 1. customers

Purpose:
Stores customer information.

| Column | Description |
|----------|-------------|
| customer_id | Order-level customer identifier |
| customer_unique_id | Unique customer identifier |
| customer_city | Customer city |
| customer_state | Customer state |

---

### 2. orders

Purpose:
Stores order lifecycle information.

| Column | Description |
|----------|-------------|
| order_id | Unique order identifier |
| customer_id | Customer reference |
| order_status | Order status |
| order_purchase_timestamp | Purchase date |
| order_approved_at | Approval date |
| order_delivered_customer_date | Delivery date |
| order_estimated_delivery_date | Expected delivery date |

---

### 3. order_items

Purpose:
Stores product-level order information.

| Column | Description |
|----------|-------------|
| order_id | Order reference |
| product_id | Product reference |
| seller_id | Seller reference |
| price | Product price |
| freight_value | Shipping cost |

---

### 4. order_payments

Purpose:
Stores payment transactions.

| Column | Description |
|----------|-------------|
| order_id | Order reference |
| payment_type | Payment method |
| payment_value | Amount paid |

---

### 5. order_reviews

Purpose:
Stores customer review information.

| Column | Description |
|----------|-------------|
| review_id | Review identifier |
| order_id | Order reference |
| review_score | Customer rating |

---

### 6. products

Purpose:
Stores product information.

| Column | Description |
|----------|-------------|
| product_id | Product identifier |
| product_category_name | Product category |

---

### 7. sellers

Purpose:
Stores seller information.

| Column | Description |
|----------|-------------|
| seller_id | Seller identifier |
| seller_city | Seller city |
| seller_state | Seller state |

---

### 8. category_trans

Purpose:
Maps Portuguese categories to English categories.

| Column | Description |
|----------|-------------|
| product_category_name | Portuguese category |
| product_category_name_english | English category |

---

### 9. geo

Purpose:
Stores geographic coordinates.

| Column | Description |
|----------|-------------|
| geolocation_zip_code_prefix | ZIP code |
| geolocation_city | City |
| geolocation_state | State |