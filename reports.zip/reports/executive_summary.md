# Executive Summary

## Overview

This project analyzes the Olist Brazilian E-Commerce dataset to evaluate marketplace performance across customers, products, and sellers. The objective was to identify revenue drivers, customer purchasing patterns, and opportunities for business growth.

---

## Key Metrics

| Metric               | Value   |
| -------------------- | ------- |
| Total Revenue        | 15.42M  |
| Total Orders         | ~97K    |
| Total Customers      | ~93.36K |
| Total Sellers        | ~3,090  |
| Average Review Score | ~4.04   |
| Repeat Customer Rate | 3.0%    |

---

## Key Findings

### Customer Insights

* High Value Customers represent only 4.57% of the customer base but contribute 25.53% of total revenue.
* Medium Value Customers contribute the largest share of revenue at 57.54%.
* The repeat customer rate is only 3.0%, with 2,801 repeat customers compared to 90,557 one-time buyers, highlighting a significant customer retention opportunity.

### Product Insights

* Health & Beauty, Watches, and Bed/Bath/Table are the highest revenue-generating categories.
* These three categories contribute 26.17% of total marketplace revenue.
* The top-performing categories account for more than one-fourth of total revenue, highlighting category-level revenue concentration.

### Seller Insights

* Top Revenue Sellers contribute 29.21% of marketplace revenue.
* Revenue generation is concentrated among a relatively small group of high-performing sellers.
* Some high-revenue seller groups exhibit lower customer satisfaction scores, indicating opportunities for service quality improvement.

---

## Business Impact

* Customer retention represents the largest growth opportunity, as only 3.0% of customers make repeat purchases.
* Revenue concentration among a limited number of categories and sellers increases business dependency and operational risk.
* High Value Customers generate a disproportionate share of revenue and should be prioritized through targeted retention strategies.

---

## Strategic Recommendations

### Increase Customer Retention

Implement loyalty programs, personalized recommendations, and post-purchase engagement initiatives to increase repeat purchases and customer lifetime value.

### Expand High-Performing Categories

Increase marketing and operational investment in categories that demonstrate strong revenue generation and customer satisfaction.

### Strengthen Seller Monitoring

Track seller review scores and performance metrics to improve customer experience and maintain marketplace quality standards.

### Reduce Revenue Concentration Risk

Diversify revenue streams by supporting emerging product categories and developing lower-performing seller segments.

---

## Conclusion

The analysis reveals that marketplace growth is primarily driven by a small group of high-value customers, top-performing categories, and leading sellers. Improving customer retention, expanding successful product categories, and maintaining seller quality represent the strongest opportunities for sustainable marketplace growth.
