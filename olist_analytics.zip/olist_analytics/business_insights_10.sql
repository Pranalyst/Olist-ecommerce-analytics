-- category risk and opportunity matrix
SELECT
ct.product_category_name_english AS category,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.order_id) AS total_orders,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY category
ORDER BY revenue DESC;

-- seller risk matrix
SELECT
oi.seller_id,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.order_id) AS total_orders,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM order_items oi
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY oi.seller_id
ORDER BY revenue DESC;

-- Customer retention
WITH customer_orders AS
(
SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id) AS total_orders
FROM customers c
JOIN orders o
ON c.customer_id = o.customer_id
WHERE o.order_status = 'delivered'
GROUP BY c.customer_unique_id)
SELECT
CASE
WHEN total_orders = 1
THEN 'One-Time Buyer'
ELSE 'Repeat Buyer'
END customer_type,
COUNT(*) customers
FROM customer_orders
GROUP BY customer_type;