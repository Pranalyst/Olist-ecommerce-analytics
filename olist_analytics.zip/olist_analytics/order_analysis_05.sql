-- total orders
SELECT
COUNT(*) total_orders
FROM orders;

-- order status distribution
SELECT
order_status,
COUNT(*) orders
FROM orders
GROUP BY order_status
ORDER BY orders DESC;

-- order status percentage
SELECT
order_status,
COUNT(*) orders,
ROUND(
100 * COUNT(*) /
SUM(COUNT(*)) OVER(),2) percentage
FROM orders
GROUP BY order_status;

-- cancellation rate
SELECT
ROUND(
100 *
SUM(
CASE
WHEN order_status='canceled'
THEN 1
ELSE 0
END
)/COUNT(*),2) cancellation_rate
FROM orders;

-- monthly order trend
SELECT
DATE_FORMAT(
order_purchase_timestamp,
'%Y-%m'
) month,COUNT(*) orders
FROM orders
GROUP BY month
ORDER BY orders desc;

-- month on month growth
WITH monthly_orders AS
(SELECT
DATE_FORMAT(order_purchase_timestamp,'%Y-%m') month, COUNT(*) orders
FROM orders
GROUP BY month)
SELECT
month,orders,
ROUND(
100 *
(orders - LAG(orders) OVER(
ORDER BY month
))/LAG(orders) OVER(
ORDER BY month),2) growth_pct
FROM monthly_orders;

-- delivered order rate
SELECT
ROUND(
100 *SUM(
CASE
WHEN order_status='delivered'
THEN 1
ELSE 0
END
)/COUNT(*),2) delivered_rate
FROM orders;

-- orders by state
SELECT
c.customer_state,
COUNT(DISTINCT o.order_id) orders
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_state
ORDER BY orders DESC;

-- orders per customer
SELECT
ROUND(AVG(order_count),2) avg_orders_per_customer
FROM
(SELECT
c.customer_unique_id, COUNT(o.order_id) order_count
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_unique_id) x;

-- avg items per order
SELECT
ROUND(AVG(items_per_order),2)AS avg_items_per_order
FROM
(
SELECT
order_id,
COUNT(*) items_per_order
FROM order_items
GROUP BY order_id) x;

-- order value distribution
WITH order_value AS
(
SELECT
o.order_id,
SUM(op.payment_value) value
FROM orders o
JOIN order_payments op
ON o.order_id=op.order_id
GROUP BY o.order_id
)
SELECT
CASE
WHEN value < 100 THEN 'Low'
WHEN value < 500 THEN 'Medium'
ELSE 'High'
END order_bucket,
COUNT(*) orders
FROM order_value
GROUP BY order_bucket;