-- Avg delivery time
SELECT
ROUND(AVG(DATEDIFF(
order_delivered_customer_date,
order_purchase_timestamp)),2)
AS avg_delivery_days
FROM orders
WHERE order_status='delivered';

-- Fastest and slowest deliveries
SELECT
MIN(DATEDIFF(
order_delivered_customer_date,
order_purchase_timestamp
)) fastest_delivery,
MAX(DATEDIFF(
order_delivered_customer_date,
order_purchase_timestamp)) slowest_delivery
FROM orders
WHERE order_status='delivered';

-- Delivery time distribution
SELECT
CASE
WHEN delivery_days <= 5 THEN '0-5 Days'
WHEN delivery_days <= 10 THEN '6-10 Days'
WHEN delivery_days <= 15 THEN '11-15 Days'
ELSE '15+ Days'
END delivery_bucket,
COUNT(*) orders
FROM
(SELECT DATEDIFF(
order_delivered_customer_date,
order_purchase_timestamp
) delivery_days
FROM orders
WHERE order_status='delivered') x
GROUP BY delivery_bucket;

-- Avg approval time
SELECT
ROUND(AVG(DATEDIFF(
order_approved_at,
order_purchase_timestamp)),2)
AS avg_approval_days
FROM orders
WHERE order_approved_at IS NOT NULL;

-- Avg Shipping time
SELECT
ROUND(AVG(DATEDIFF(
order_delivered_carrier_date,
order_approved_at)),2)
AS avg_shipping_days
FROM orders
WHERE order_status='delivered';

-- Avg transmit time
SELECT
ROUND(AVG(DATEDIFF(
order_delivered_customer_date,
order_delivered_carrier_date)),2)
AS avg_transit_days
FROM orders
WHERE order_status='delivered';

-- Late delivery rate
SELECT
ROUND(100 *SUM(
CASE
WHEN order_delivered_customer_date >
order_estimated_delivery_date
THEN 1
ELSE 0
END
)/COUNT(*),2)
AS late_delivery_rate
FROM orders
WHERE order_status='delivered';

-- Early delivery rate
SELECT
ROUND(100 *SUM(
CASE
WHEN order_delivered_customer_date <
order_estimated_delivery_date
THEN 1
ELSE 0
END
)/COUNT(*),2)
AS early_delivery_rate
FROM orders
WHERE order_status='delivered';

-- Delivery performance by state
SELECT
c.customer_state,
ROUND(AVG(DATEDIFF(
o.order_delivered_customer_date,
o.order_purchase_timestamp
)),2)
AS avg_delivery_days
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
WHERE o.order_status='delivered'
GROUP BY c.customer_state
ORDER BY avg_delivery_days DESC;


-- Delivery vs review score
SELECT
CASE
WHEN delivery_days <= 6 THEN 'Fast'
WHEN delivery_days <= 12 THEN 'Medium'
ELSE 'Slow'
END delivery_speed,
ROUND(AVG(review_score),2)
AS avg_review
FROM
(SELECT
o.order_id,
DATEDIFF(
o.order_delivered_customer_date,
o.order_purchase_timestamp
) delivery_days,
r.review_score
FROM orders o
JOIN order_reviews r
ON o.order_id=r.order_id
WHERE o.order_status='delivered') x
GROUP BY delivery_speed;

