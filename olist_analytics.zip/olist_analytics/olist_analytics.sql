use olist;
-- Annual Revenue
select round(sum(payment_value),2) as annual_revenue from order_payments;

-- Monthly Revenue
SELECT
    DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m') AS month,
    round(SUM(op.payment_value),2) AS monthly_revenue
FROM orders o
JOIN order_payments op
    ON o.order_id = op.order_id
GROUP BY month
ORDER BY month;

-- Revenue by State
select c.customer_state, round(sum(op.payment_value),2) as Revenue_by_state from customers c 
join orders o on c.customer_id = o.customer_id
join order_payments op on o.order_id = op.order_id
group by c.customer_state;

-- Top Categories (with respect to total orders) with avg review score
select ct.product_category_name, count(distinct oi.order_id)  AS total_orders, avg(ors.review_score) as Avg_review from category_trans as ct 
join products p on ct.product_category_name = p.product_category_name
join order_items oi on p.product_id = oi.product_id
join order_reviews ors on oi.order_id = ors.order_id
group by ct.product_category_name
order by total_orders desc;

-- Revenue v/s Delivery Days
select ct.product_category_name, 
round(sum(oi.price),2) as Revenue,
round(avg(datediff(order_delivered_customer_date,order_purchase_timestamp))) as Avg_delivery_days
from category_trans ct 
join products p on ct.product_category_name = p.product_category_name
join order_items oi on p.product_id = oi.product_id
join orders o on oi.order_id = o.order_id
group by ct.product_category_name
order by Revenue desc;


-- Order Status Analysis
SELECT order_status, COUNT(*) as orders
FROM orders
GROUP BY order_status;

-- Customer Analytics
SELECT COUNT(DISTINCT customer_unique_id) AS total_customers
FROM customers;

-- Monthly new customers
SELECT
DATE_FORMAT(first_purchase,'%Y-%m') AS month,
COUNT(*) AS new_customers
FROM (
    SELECT
        c.customer_unique_id,
        MIN(o.order_purchase_timestamp) AS first_purchase
    FROM customers c
    JOIN orders o
    ON c.customer_id = o.customer_id
    GROUP BY c.customer_unique_id
) t
GROUP BY month
ORDER BY month;

-- Repeat customers
SELECT
COUNT(*) repeat_customers
FROM (
    SELECT
        c.customer_unique_id,
        COUNT(DISTINCT o.order_id) total_orders
    FROM customers c
    JOIN orders o
    ON c.customer_id=o.customer_id
    GROUP BY c.customer_unique_id
    HAVING COUNT(DISTINCT o.order_id) > 1
) x;

-- Repeat Customer rate
WITH customer_orders AS
(
SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id) total_orders
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_unique_id
)

SELECT
ROUND(
100.0 *
SUM(CASE WHEN total_orders > 1 THEN 1 ELSE 0 END)
/
COUNT(*)
,2
) AS repeat_rate
FROM customer_orders;

-- Top Customers
SELECT
c.customer_unique_id,
ROUND(
SUM(op.payment_value),2) revenue,
RANK() OVER(
ORDER BY SUM(op.payment_value) DESC
) customer_rank
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
GROUP BY c.customer_unique_id;

-- AOV by Customer
SELECT
c.customer_unique_id,
ROUND(
SUM(op.payment_value)/COUNT(DISTINCT o.order_id),
2) avg_order_value
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
GROUP BY c.customer_unique_id;

-- Customer Geography
SELECT
customer_state,
COUNT(DISTINCT customer_unique_id) no_customers
FROM customers
GROUP BY customer_state
ORDER BY no_customers DESC;