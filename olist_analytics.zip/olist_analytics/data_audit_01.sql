use olist;
-- Dataset Overview
SELECT 'customers' AS table_name, COUNT(*) AS row_count
FROM customers
UNION ALL
SELECT 'orders', COUNT(*)
FROM orders
UNION ALL
SELECT 'order_items', COUNT(*)
FROM order_items
UNION ALL
SELECT 'order_payments', COUNT(*)
FROM order_payments
UNION ALL
SELECT 'order_reviews', COUNT(*)
FROM order_reviews
UNION ALL
SELECT 'products', COUNT(*)
FROM products
UNION ALL
SELECT 'sellers', COUNT(*)
FROM sellers
UNION ALL
SELECT 'geo', COUNT(*)
FROM geo;

-- Primary Key investigation
-- Is order_id truly unique? : Yes
SELECT
order_id,
COUNT(*)
FROM orders
GROUP BY order_id
HAVING COUNT(*) > 1;

-- Product id
SELECT
product_id,
COUNT(*)
FROM products
GROUP BY product_id
HAVING COUNT(*) > 1;

-- Seller id
SELECT
seller_id,
COUNT(*)
FROM sellers
GROUP BY seller_id
HAVING COUNT(*) > 1;

-- Customer Identity Investigation
-- difference between customer_id and customer_unique_id
SELECT
COUNT(DISTINCT customer_id)
FROM customers;

SELECT
COUNT(DISTINCT customer_unique_id)
FROM customers;

SELECT
customer_unique_id,
COUNT(*)
FROM customers
GROUP BY customer_unique_id
HAVING COUNT(*) > 1
LIMIT 20;

-- Missing Value Analysis
SELECT
COUNT(*) total_rows,
COUNT(order_approved_at) approved_count,
COUNT(order_delivered_customer_date) delivered_count
FROM orders;

SELECT
order_status,
COUNT(*)
FROM orders
WHERE order_delivered_customer_date IS NULL
GROUP BY order_status;

-- Order Status Investigation
SELECT
order_status,
COUNT(*) orders
FROM orders
GROUP BY order_status
ORDER BY orders DESC;

-- What % are canceled?
SELECT
ROUND(
100 * SUM(CASE
WHEN order_status='canceled'
THEN 1
ELSE 0
END)/COUNT(*),2) AS cancel_rate
FROM orders;

-- Date Range Investigation
-- What period does the dataset cover?
SELECT
MIN(order_purchase_timestamp) as start_date,
MAX(order_purchase_timestamp) as latest_date
FROM orders;

-- Relationship Validation
-- Does every order have payment data?
SELECT
COUNT(*)
FROM orders o
LEFT JOIN order_payments op
ON o.order_id = op.order_id
WHERE op.order_id IS NULL;

-- Revenue Validation
-- Product price
SELECT
SUM(price)  
FROM order_items;

-- Customer payment
SELECT
SUM(payment_value)
FROM order_payments;

