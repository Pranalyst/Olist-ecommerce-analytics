-- seller performance matrix
SELECT
oi.seller_id,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.order_id) AS total_orders,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM order_items oi
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY oi.seller_id
ORDER BY revenue DESC;

-- Revenue contribution by seller
WITH seller_revenue AS
(SELECT
seller_id,
SUM(price) AS revenue
FROM order_items
GROUP BY seller_id)
SELECT
seller_id,
ROUND(revenue,2) AS revenue,
ROUND(100 * revenue /SUM(revenue) OVER(),2) AS contribution_pct
FROM seller_revenue
ORDER BY revenue DESC;

-- seller revenue vs customer satisfaction
SELECT
oi.seller_id,
ROUND(SUM(oi.price),2) AS revenue,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM order_items oi
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY oi.seller_id
ORDER BY revenue DESC;

-- seller state perfomance
SELECT
s.seller_state,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.seller_id) AS total_sellers
FROM sellers s
JOIN order_items oi
ON s.seller_id = oi.seller_id
GROUP BY s.seller_state
ORDER BY revenue DESC;

-- seller efficiency
WITH seller_metrics AS
(SELECT
seller_id,
SUM(price) AS revenue,
COUNT(DISTINCT order_id) AS total_orders
FROM order_items
GROUP BY seller_id)
SELECT
seller_id,
ROUND(revenue,2) AS revenue,
total_orders,
ROUND(revenue / total_orders,2) AS revenue_per_order
FROM seller_metrics
ORDER BY revenue_per_order DESC;