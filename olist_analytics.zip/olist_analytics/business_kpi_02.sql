/*
KPI: Total Revenue

Definition:
Total customer payments received.

Source:
order_payments

Metric Type:
Financial
*/

SELECT
ROUND(SUM(payment_value),2) AS total_revenue
FROM order_payments;

-- total orders
SELECT
COUNT(DISTINCT order_id) AS total_orders
FROM orders;

-- actual delivered orders
SELECT
COUNT(*) AS delivered_orders
FROM orders
WHERE order_status='delivered';

-- AOV
SELECT
ROUND(
SUM(op.payment_value)
/COUNT(DISTINCT o.order_id),2) AS avg_order_value
FROM orders o
JOIN order_payments op
ON o.order_id = op.order_id;

-- Avg review score
SELECT
ROUND(
AVG(review_score),2) AS avg_review_score
FROM order_reviews;

-- Avg delivery time
SELECT
ROUND(
AVG(
DATEDIFF(
order_delivered_customer_date,
order_purchase_timestamp)),2) AS avg_delivery_days
FROM orders
WHERE order_status='delivered';

-- late delivery rate
SELECT
ROUND(
100.0 *
SUM(
CASE
WHEN order_delivered_customer_date >
order_estimated_delivery_date
THEN 1
ELSE 0
END
)/COUNT(*),2) AS late_delivery_rate
FROM orders
WHERE order_status='delivered';


-- Revenue per Seller
SELECT
ROUND(
SUM(oi.price)
/COUNT(DISTINCT seller_id),2) AS revenue_per_seller
FROM order_items oi;