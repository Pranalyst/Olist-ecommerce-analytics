-- category performance matrix
/*
Business Question:
Which categories perform best in terms of
Revenue, Orders and Reviews?
*/

SELECT
ct.product_category_name_english AS category,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.order_id) AS total_orders,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY category
ORDER BY revenue DESC;

-- revenue contribution by category 
WITH category_revenue AS
(SELECT
ct.product_category_name_english AS category,
SUM(oi.price) AS revenue
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
GROUP BY category)
SELECT
category,ROUND(revenue,2) AS revenue,
ROUND(
100 * revenue /
SUM(revenue) OVER(),
2) AS contribution_pct
FROM category_revenue
ORDER BY revenue DESC;

-- revenue vs customer satisfaction
SELECT
ct.product_category_name_english AS category,
ROUND(SUM(oi.price),2) AS revenue,
ROUND(AVG(r.review_score),2) AS avg_review
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY category
HAVING revenue > (
    SELECT AVG(category_rev)
    FROM
    (
        SELECT
        SUM(oi2.price) AS category_rev
        FROM category_trans ct2
        JOIN products p2
        ON ct2.product_category_name = p2.product_category_name
        JOIN order_items oi2
        ON p2.product_id = oi2.product_id
        GROUP BY ct2.product_category_name_english
    ) x)
ORDER BY avg_review ASC;

-- Top 10 revenue generating product category
SELECT
ct.product_category_name_english AS category,
ROUND(SUM(oi.price),2) AS revenue
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
GROUP BY category
ORDER BY revenue DESC
limit 10;

-- Best selling product category
SELECT
ct.product_category_name_english AS category,
COUNT(DISTINCT oi.order_id) AS total_orders
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
GROUP BY category
ORDER BY total_orders DESC
LIMIT 10;