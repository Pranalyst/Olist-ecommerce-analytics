SELECT
COUNT(DISTINCT customer_id),
COUNT(DISTINCT customer_unique_id)
FROM customers;

-- total customers
SELECT
COUNT(DISTINCT customer_unique_id)
AS total_customers
FROM customers;

-- new customers by month
WITH first_purchase AS
(
SELECT
c.customer_unique_id,
MIN(o.order_purchase_timestamp) first_purchase
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_unique_id
)
SELECT
DATE_FORMAT(first_purchase,'%Y-%m') month,
COUNT(*) new_customers
FROM first_purchase
GROUP BY month
ORDER BY month;

-- repeat customers
SELECT
COUNT(*) repeat_customers
FROM
(
SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id) total_orders
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_unique_id
HAVING COUNT(DISTINCT o.order_id) > 1
) x;

-- repeat customer rate
WITH customer_orders AS
(
SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id) total_orders
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_unique_id
)
SELECT
ROUND(
100 *
SUM(
CASE
WHEN total_orders > 1
THEN 1
ELSE 0
END
)/COUNT(*),2) repeat_rate
FROM customer_orders;

-- customer distribution by state
SELECT
customer_state,
COUNT(distinct customer_unique_id) customers
FROM customers
GROUP BY customer_state
ORDER BY customers DESC;

-- orders per customer
SELECT ROUND(AVG(total_orders),2) avg_orders_per_customer
FROM
(
SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id) total_orders
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
GROUP BY c.customer_unique_id
) x;

-- Top customers by revenue
SELECT
c.customer_unique_id,
ROUND(SUM(op.payment_value),2) revenue
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
GROUP BY c.customer_unique_id
ORDER BY revenue DESC;

-- avg revenue per customer
SELECT
ROUND(
SUM(op.payment_value)
/COUNT(DISTINCT c.customer_unique_id),2) revenue_per_customer
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id;

-- customer segmentation
WITH customer_revenue AS
(
SELECT
c.customer_unique_id,
SUM(op.payment_value) revenue
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
GROUP BY c.customer_unique_id
)
SELECT
CASE
WHEN revenue < 100 THEN 'Low Value'
WHEN revenue < 500 THEN 'Medium Value'
ELSE 'High Value'
END customer_segment,
COUNT(*) customers
FROM customer_revenue
GROUP BY customer_segment;

