-- Monthly revenue
CREATE VIEW vw_monthly_revenue AS
SELECT
DATE_FORMAT(
o.order_purchase_timestamp,
'%Y-%m') AS month,
ROUND(SUM(op.payment_value),2) AS revenue
FROM orders o
JOIN order_payments op
ON o.order_id = op.order_id
WHERE o.order_status = 'delivered'
GROUP BY month
ORDER BY month;

select * from vw_monthly_revenue;

-- Category Performance
CREATE VIEW vw_category_performance AS
SELECT
ct.product_category_name_english AS category,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.order_id) AS total_orders,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM category_trans ct
JOIN products p
ON ct.product_category_name = p.product_category_name
JOIN order_items oi
ON p.product_id = oi.product_id
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY category;

select * from vw_category_performance;

-- Customer segments
CREATE VIEW vw_customer_segments AS
WITH customer_value AS
(
SELECT c.customer_unique_id, SUM(op.payment_value) AS spend
FROM customers c
JOIN orders o
ON c.customer_id = o.customer_id
JOIN order_payments op
ON o.order_id = op.order_id
WHERE o.order_status = 'delivered'
GROUP BY c.customer_unique_id)
SELECT
customer_unique_id,
ROUND(spend,2) AS spend,
CASE
WHEN spend < 100
THEN 'Low Value'
WHEN spend < 500
THEN 'Medium Value'
ELSE 'High Value'
END AS customer_segment
FROM customer_value;

select * from vw_customer_segments;

-- Seller Performance
CREATE VIEW vw_seller_performance AS
SELECT
oi.seller_id,
ROUND(SUM(oi.price),2) AS revenue,
COUNT(DISTINCT oi.order_id) AS total_orders,
ROUND(AVG(r.review_score),2) AS avg_review_score
FROM order_items oi
JOIN order_reviews r
ON oi.order_id = r.order_id
GROUP BY oi.seller_id;

select * from vw_seller_performance;

-- Delivery Metrics
CREATE VIEW vw_delivery_metrics AS
SELECT
o.order_id,
o.order_status,
DATEDIFF(
o.order_delivered_customer_date,
o.order_purchase_timestamp) AS delivery_days,
DATEDIFF(
o.order_estimated_delivery_date,
o.order_delivered_customer_date) AS delivery_variance
FROM orders o
WHERE
o.order_status = 'delivered'
AND o.order_delivered_customer_date IS NOT NULL;

select * from vw_delivery_metrics;

-- Customer retention
CREATE VIEW vw_customer_retention AS
SELECT
c.customer_unique_id, COUNT(DISTINCT o.order_id) AS total_orders
FROM customers c
JOIN orders o
ON c.customer_id = o.customer_id
WHERE o.order_status = 'delivered'
GROUP BY c.customer_unique_id;

select * from vw_customer_retention;
-- Views
SHOW FULL TABLES WHERE TABLE_TYPE = 'VIEW';