-- customer metrics
WITH customer_rfm AS
(SELECT
c.customer_unique_id,
MAX(o.order_purchase_timestamp) AS last_purchase,
COUNT(DISTINCT o.order_id) AS frequency,
SUM(op.payment_value) AS monetary
FROM customers c
JOIN orders o
ON c.customer_id = o.customer_id
JOIN order_payments op
ON o.order_id = op.order_id
WHERE o.order_status = 'delivered'
GROUP BY c.customer_unique_id)
SELECT *
FROM customer_rfm;

-- rfm
SELECT
c.customer_unique_id,
DATEDIFF(
MAX(o.order_purchase_timestamp),
MIN(o.order_purchase_timestamp)
) AS customer_lifetime_days,
COUNT(DISTINCT o.order_id) AS frequency,
ROUND(SUM(op.payment_value),2) AS monetary
FROM customers c
JOIN orders o
ON c.customer_id = o.customer_id
JOIN order_payments op
ON o.order_id = op.order_id
WHERE o.order_status='delivered'
GROUP BY c.customer_unique_id
order by frequency desc;

-- customer value segmentation
WITH customer_value AS
(SELECT
c.customer_unique_id,
SUM(op.payment_value) AS spend
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
WHERE o.order_status='delivered'
GROUP BY c.customer_unique_id)
SELECT
CASE
WHEN spend < 100 THEN 'Low Value'
WHEN spend < 500 THEN 'Medium Value'
ELSE 'High Value'
END customer_segment,
COUNT(*) customers
FROM customer_value
GROUP BY customer_segment;

-- repeat customer
WITH customer_orders AS
(SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id)
AS total_orders
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
WHERE o.order_status='delivered'
GROUP BY c.customer_unique_id)
SELECT
CASE
WHEN total_orders = 1
THEN 'One-Time Buyer'
ELSE 'Repeat Buyer'
END customer_type,
COUNT(*) customers
FROM customer_orders
GROUP BY customer_type;

-- customer segmentation
WITH customer_rfm AS
(SELECT
c.customer_unique_id,
COUNT(DISTINCT o.order_id) AS frequency,
SUM(op.payment_value) AS monetary
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
WHERE o.order_status='delivered'
GROUP BY c.customer_unique_id)
SELECT
CASE
WHEN frequency >= 5 AND monetary >= 1000
THEN 'Champion'
WHEN frequency >= 3 AND monetary >= 500
THEN 'Loyal'
WHEN frequency = 1
THEN 'One-Time Buyer'
ELSE 'Occasional Buyer'
END customer_segment,
COUNT(*) customers
FROM customer_rfm
GROUP BY customer_segment;