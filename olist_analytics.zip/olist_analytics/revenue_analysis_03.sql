/*
Business Question:
How has revenue changed over time?

Importance:
Identifies growth trends and seasonality.
*/
-- monthly revenue
SELECT
DATE_FORMAT(o.order_purchase_timestamp,'%Y-%m') AS month,
ROUND(SUM(op.payment_value),2) AS revenue
FROM orders o
JOIN order_payments op
ON o.order_id = op.order_id
WHERE o.order_status='delivered'
GROUP BY month
ORDER BY month;

-- Month over month growth
WITH monthly_revenue AS
(
SELECT
DATE_FORMAT(o.order_purchase_timestamp,'%Y-%m') AS month,
SUM(op.payment_value) revenue
FROM orders o
JOIN order_payments op
ON o.order_id = op.order_id
WHERE o.order_status='delivered'
GROUP BY month
)

SELECT
month,
ROUND(revenue,2) revenue,

ROUND(
100 *
(revenue -
LAG(revenue) OVER(ORDER BY month))
/
LAG(revenue) OVER(ORDER BY month)
,2
) AS growth_pct

FROM monthly_revenue;

-- Revenue by state
SELECT
c.customer_state,
ROUND(SUM(op.payment_value),2) revenue
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
WHERE o.order_status='delivered'
GROUP BY c.customer_state
ORDER BY revenue DESC;

-- Revenue Contribution by State
WITH state_revenue AS
(SELECT
c.customer_state,
SUM(op.payment_value) revenue
FROM customers c
JOIN orders o
ON c.customer_id=o.customer_id
JOIN order_payments op
ON o.order_id=op.order_id
WHERE o.order_status='delivered'
GROUP BY c.customer_state)
SELECT
customer_state,
ROUND(revenue,2) as revenue,
ROUND(
100 * revenue /
SUM(revenue) OVER(),2) contribution_pct
FROM state_revenue
ORDER BY revenue DESC;

-- revenue contribution by product category
SELECT
ct.product_category_name_english,
ROUND(SUM(oi.price),2) revenue
FROM category_trans ct
JOIN products p
ON ct.product_category_name =
p.product_category_name
JOIN order_items oi
ON p.product_id=oi.product_id
GROUP BY
ct.product_category_name_english
ORDER BY revenue DESC;

-- Revenue by Seller
SELECT
seller_id, ROUND(SUM(price),2) seller_revenue
FROM order_items
GROUP BY seller_id
ORDER BY seller_revenue DESC;

-- revenue concentration
WITH seller_revenue AS
(SELECT
seller_id,
round(SUM(price) ,2)revenue
FROM order_items
GROUP BY seller_id)
SELECT *
FROM seller_revenue
ORDER BY revenue DESC;

-- Avg revenue per order
SELECT
ROUND(
SUM(op.payment_value)
/COUNT(DISTINCT o.order_id),2) revenue_per_order
FROM orders o
JOIN order_payments op
ON o.order_id=op.order_id
WHERE o.order_status='delivered';

-- revenue by payment type
SELECT
payment_type,
ROUND(SUM(payment_value),2) as revenue,
COUNT(*) as transactions
FROM order_payments
GROUP BY payment_type
ORDER BY revenue DESC;

-- revenue seasonality
SELECT
MONTHNAME(order_purchase_timestamp) month_name,
ROUND(SUM(payment_value),2) revenue
FROM orders o
JOIN order_payments op
ON o.order_id=op.order_id
WHERE o.order_status='delivered'
GROUP BY month_name
ORDER BY revenue DESC;